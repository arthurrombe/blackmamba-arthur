const toggleTheme = document.getElementById('toogle-theme');
const body = document.body;
const wrapper = document.querySelector('.wrapper');

toggleTheme.addEventListener('change', () => {
    body.classList.toggle('dark', toggleTheme.checked);
    wrapper.classList.toggle('dark', toggleTheme.checked);
});

// code untuk penambahan list, hapus , dan selesai

// Ambil elemen dari HTML
const todoInput = document.getElementById('todo-input');
const addButton = document.getElementById('add-btn');
const todoList = document.getElementById('todo-list');

// Variabel untuk menyimpan nomor urut
let taskCount = 0;

// Fungsi untuk menambah tugas
function addTask() {
    const taskText = todoInput.value.trim();

    // Validasi input (tidak menampilkan alert)
    if (taskText === '') {
        return; // Jika kosong, keluar dari fungsi tanpa alert
    }

    // Increment nomor urut
    taskCount++;

    // Buat elemen list
    const li = document.createElement('li');

    // Buat elemen span untuk teks tugas
    const taskSpan = document.createElement('span');
    taskSpan.textContent = `${taskCount}. ${taskText}`;

    // Tombol untuk menghapus tugas
    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'Hapus';
    deleteButton.className = 'delete-btn';
    deleteButton.onclick = function() {
        todoList.removeChild(li);
        updateTaskNumbers(); // Memperbarui nomor urut setelah tugas dihapus
    };

    // Tombol untuk menandai tugas sebagai selesai
    const completeButton = document.createElement('button');
    completeButton.textContent = 'Selesai';
    completeButton.onclick = function() {
        li.classList.toggle('completed');
    };

    // Tambahkan elemen span dan tombol ke list item
    li.appendChild(taskSpan);
    li.appendChild(completeButton);
    li.appendChild(deleteButton);

    // Tambahkan list item ke dalam todo list
    todoList.appendChild(li);

    // Reset input
    todoInput.value = '';
}

// Fungsi untuk memperbarui nomor urut setelah tugas dihapus
function updateTaskNumbers() {
    const tasks = todoList.querySelectorAll('li');
    taskCount = 0; // Reset nomor urut
    tasks.forEach((task) => {
        taskCount++;
        task.firstChild.textContent = `${taskCount}. ${task.firstChild.textContent.split('. ')[1]}`; // Update nomor urut
    });
}

// Tambahkan event listener ke tombol tambah
addButton.addEventListener('click', addTask);

// Tambahkan event listener untuk menekan tombol Enter
todoInput.addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        addTask();
    }
});



// const toggleTheme = document.getElementById('toogle-theme');
// const body = document.body;
// const wrapper = document.querySelector('.wrapper');

toggleTheme.addEventListener('change', () => {
    body.classList.toggle('dark', toggleTheme.checked);
    wrapper.classList.toggle('dark', toggleTheme.checked);
});
